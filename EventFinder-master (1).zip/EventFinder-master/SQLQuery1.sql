-- Create the database
CREATE DATABASE EventDB;
GO
USE EventDB;
GO

-- Create Users table (includes both Admin and Customers)
CREATE TABLE Users (
    UserID INT PRIMARY KEY IDENTITY(1,1),
    FullName NVARCHAR(100) NOT NULL,
    Email NVARCHAR(100) NOT NULL UNIQUE,
    Password NVARCHAR(100) NOT NULL, -- Stored as plain text
    Address NVARCHAR(255) NOT NULL,
    City NVARCHAR(100) NOT NULL,
    Role NVARCHAR(50) CHECK (Role IN ('Admin', 'Customer')) NOT NULL,
    ContactNumber NVARCHAR(20),
    DateCreated DATETIME DEFAULT GETDATE()
);
GO
-- Insert Admin user details into Users table
INSERT INTO Users (FullName, Email, Password, Address, City, Role, ContactNumber, DateCreated)
VALUES ('Admin User', 'IamAdmin@gmail.com', 'Admin@2004', '123 Admin Street', 'Admin City', 'Admin', '1234567890', GETDATE());
GO


-- Create Event Organizers table
CREATE TABLE EventOrganizers (
    OrganizerID INT PRIMARY KEY IDENTITY(1,1),
    FullName NVARCHAR(100) NOT NULL,
    Email NVARCHAR(100) NOT NULL UNIQUE,
    Password NVARCHAR(100) NOT NULL, -- Stored as plain text
    ContactNumber NVARCHAR(20),
    CompanyName NVARCHAR(100),
    Address NVARCHAR(255),
    DateCreated DATETIME DEFAULT GETDATE()
);
GO

-- Create Event Types table (Pre-populated)
CREATE TABLE EventTypes (
    EventTypeID INT PRIMARY KEY IDENTITY(1,1),
    EventTypeName NVARCHAR(100) NOT NULL UNIQUE
);
GO

-- Insert common event types
INSERT INTO EventTypes (EventTypeName) VALUES 
    ('Music Event'), 
    ('Sport Event'), 
    ('Art Exhibition'), 
    ('Conference'), 
    ('Festival');
GO

-- Create Events table
CREATE TABLE Events (
    EventID INT PRIMARY KEY IDENTITY(1,1),
    OrganizerID INT FOREIGN KEY REFERENCES EventOrganizers(OrganizerID),
    EventName NVARCHAR(255) NOT NULL,
    EventTypeID INT FOREIGN KEY REFERENCES EventTypes(EventTypeID),
    EventDate DATETIME NOT NULL,
    Capacity INT NOT NULL,
    GeneralTicketPrice DECIMAL(10,2),
    VIPTicketPrice DECIMAL(10,2),
    VVIPTicketPrice DECIMAL(10,2),
    BackstagePassPrice DECIMAL(10,2),
    Poster VARBINARY(MAX), -- Store the actual image as VARBINARY
    Address NVARCHAR(255) NOT NULL,
    City NVARCHAR(100) NOT NULL,
    DateCreated DATETIME DEFAULT GETDATE(),
    Status NVARCHAR(50) CHECK (Status IN ('Pending', 'Approved', 'Postponed')) DEFAULT 'Pending'
);
GO

-- Create Guests table
CREATE TABLE Guests (
    GuestID INT PRIMARY KEY IDENTITY(1,1),
    EventID INT FOREIGN KEY REFERENCES Events(EventID),
    GuestName NVARCHAR(100) NOT NULL,
    StageName NVARCHAR(100),
    Profession NVARCHAR(100),
    ProfilePic VARBINARY(MAX), -- Store the guest's picture as VARBINARY
    Biography NVARCHAR(500),
    DateAdded DATETIME DEFAULT GETDATE()
);
GO

-- Create Tickets table (Ticket info for each event)
CREATE TABLE Tickets (
    TicketID INT PRIMARY KEY IDENTITY(1,1),
    EventID INT FOREIGN KEY REFERENCES Events(EventID),
    TicketType NVARCHAR(50) CHECK (TicketType IN ('General', 'VIP', 'VVIP', 'Backstage')) NOT NULL,
    Price DECIMAL(10,2) NOT NULL,
    DateCreated DATETIME DEFAULT GETDATE()
);
GO

-- Create Transactions table (Records of ticket sales for events)
CREATE TABLE Transactions (
    TransactionID INT PRIMARY KEY IDENTITY(1,1),
    UserID INT FOREIGN KEY REFERENCES Users(UserID),
    EventID INT FOREIGN KEY REFERENCES Events(EventID),
    TicketType NVARCHAR(50) NOT NULL,
    Quantity INT NOT NULL,
    TotalAmount DECIMAL(10,2) NOT NULL,
    PaymentMethod NVARCHAR(50) CHECK (PaymentMethod IN ('PayPal')) NOT NULL,
    PaymentStatus NVARCHAR(50) CHECK (PaymentStatus IN ('Pending', 'Completed', 'Failed')) DEFAULT 'Pending',
    QRCode VARBINARY(MAX), -- QR code generated for the user stored as VARBINARY
    TicketPDF VARBINARY(MAX), -- Ticket PDF for the user stored as VARBINARY
    DatePurchased DATETIME DEFAULT GETDATE()
);
GO

-- Create Notifications table (For sending notifications to users)
CREATE TABLE Notifications (
    NotificationID INT PRIMARY KEY IDENTITY(1,1),
    UserID INT FOREIGN KEY REFERENCES Users(UserID),
    EventID INT FOREIGN KEY REFERENCES Events(EventID),
    Message NVARCHAR(500) NOT NULL,
    IsRead BIT DEFAULT 0,
    DateSent DATETIME DEFAULT GETDATE()
);
GO

-- Create Event Postponement table (Track postponed events)
CREATE TABLE EventPostponements (
    PostponementID INT PRIMARY KEY IDENTITY(1,1),
    EventID INT FOREIGN KEY REFERENCES Events(EventID),
    OldEventDate DATETIME NOT NULL,
    NewEventDate DATETIME NOT NULL,
    Reason NVARCHAR(255),
    DateNotified DATETIME DEFAULT GETDATE()
);
GO

-- Create a Ticket Sales Summary table
CREATE TABLE TicketSalesSummary (
    EventID INT FOREIGN KEY REFERENCES Events(EventID),
    TotalTicketsSold INT NOT NULL,
    TotalRevenue DECIMAL(10,2) NOT NULL
);
GO

ALTER TABLE TicketSalesSummary
ADD SummaryID INT IDENTITY(1,1) PRIMARY KEY;
GO


-- Create a table for event-related documents
CREATE TABLE EventDocuments (
    DocumentID INT PRIMARY KEY IDENTITY(1,1),
    EventID INT FOREIGN KEY REFERENCES Events(EventID),
    DocumentName NVARCHAR(100),
    DocumentContent VARBINARY(MAX), -- Store the document as a binary file
    DateUploaded DATETIME DEFAULT GETDATE()
);
GO

-- Create Complaints table (For customer complaints)
CREATE TABLE Complaints (
    ComplaintID INT PRIMARY KEY IDENTITY(1,1),
    UserID INT FOREIGN KEY REFERENCES Users(UserID),
    AdminID INT FOREIGN KEY REFERENCES Users(UserID),
    ComplaintText NVARCHAR(500) NOT NULL,
    ResponseText NVARCHAR(500),
    Status NVARCHAR(50) CHECK (Status IN ('Pending', 'Resolved')) DEFAULT 'Pending',
    DateSubmitted DATETIME DEFAULT GETDATE(),
    DateResolved DATETIME
);
GO


