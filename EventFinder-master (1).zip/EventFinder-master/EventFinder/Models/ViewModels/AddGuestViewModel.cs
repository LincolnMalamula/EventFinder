﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
namespace EventFinder.Models.ViewModels
{
    public class AddGuestViewModel
    {
        public int EventID { get; set; }
        public string GuestName { get; set; }
        public string StageName { get; set; }
        public string Profession { get; set; }
        public string Biography { get; set; }
        public HttpPostedFileBase ProfilePic { get; set; } // Guest picture file upload
    }
}