﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
namespace EventFinder.Models.ViewModels
{
    public class EventAnalysisViewModel
    {
        public int EventID { get; set; }
        public string EventName { get; set; }
        public int TotalTicketsSold { get; set; }
        public decimal TotalRevenue { get; set; }
        public List<TicketTypeAnalysis> TicketsByType { get; set; }
    }

    public class TicketTypeAnalysis
    {
        public string TicketType { get; set; }
        public int TicketsSold { get; set; }
        public decimal Revenue { get; set; }
    }
}

