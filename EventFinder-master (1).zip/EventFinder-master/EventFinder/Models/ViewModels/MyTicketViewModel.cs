﻿using System;

namespace EventFinder.Models.ViewModels
{
    public class MyTicketViewModel
    {
        public int TransactionID { get; set; }
        public string TicketType { get; set; }
        public decimal TotalAmount { get; set; }
        public DateTime DatePurchased { get; set; }
        public string EventName { get; set; }
        public byte[] EventPoster { get; set; }
        public string EventType { get; set; }
    }
}
