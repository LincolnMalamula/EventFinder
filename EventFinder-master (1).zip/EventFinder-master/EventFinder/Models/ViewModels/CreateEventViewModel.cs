﻿using System;
using System.Web;

namespace EventFinder.Models.ViewModels
{
    public class CreateEventViewModel
    {
        public string EventName { get; set; }
        public int EventTypeID { get; set; }
        public DateTime EventDate { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public int Capacity { get; set; }
        public decimal GeneralTicketPrice { get; set; }
        public decimal VIPTicketPrice { get; set; }
        public decimal VVIPTicketPrice { get; set; }
        public decimal BackstagePassPrice { get; set; }
        public HttpPostedFileBase Poster { get; set; } // Poster file upload
    }
}
