﻿using EventFinder.Models;
using System;
using System.Linq;
using System.Web.Mvc;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq; // For parsing JSON responses
using System.Collections.Generic;
using iText.Kernel.Pdf;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Properties;

using PayPal.Api;
using QRCoder;

using System.Configuration;
using System.Drawing;
using System.Globalization;
using System.IO;
using iText.IO.Image;
using System.Net.Mail;
using EventFinder.Models.ViewModels;
using Newtonsoft.Json;

namespace EventFinder.Controllers
{
    public class CustomerController : Controller
    {
        private readonly EventDBEntities5 db = new EventDBEntities5();
        private readonly string googleApiKey = "AIzaSyAZKmOdrjmeLsp6j8YMACajDtuF13yY5QU";

        // GET: Customer Home
        [HttpGet]
        public ActionResult Home()
        {
            if (Session["UserID"] == null)
            {
                return RedirectToAction("Login", "Account");
            }

            return View();
        }

        // GET: Local Events (Within 50km)
        [HttpGet]
        public async Task<ActionResult> LocalEvents()
        {
            if (Session["UserID"] == null)
            {
                return RedirectToAction("Login", "Account");
            }

            // Retrieve logged-in customer's address and city
            var customerID = (int)Session["UserID"];
            var customer = db.Users.Find(customerID);
            if (customer == null)
            {
                return HttpNotFound();
            }

            // Use Google Distance Matrix API to calculate the distance between the customer city and event cities
            var localEvents = new List<Event>();

            foreach (var evnt in db.Events.Where(e => e.Status == "Approved"))
            {
                double distance = await CalculateDistanceAsync(customer.City, evnt.City);
                if (distance <= 50) // Filter events within 50km
                {
                    localEvents.Add(evnt);
                }
            }

            return View(localEvents);
        }

        public ActionResult SearchResults()
        {
            return View();
        }
        // GET: Search Events by City
        [HttpGet]
        public ActionResult SearchByCity()
        {
            if (Session["UserID"] == null)
            {
                return RedirectToAction("Login", "Account");
            }

            // Get all active events (events with future dates)
            var activeEvents = db.Events.Where(e => e.EventDate >= DateTime.Now && e.Status == "Approved").ToList();

            return View(activeEvents);
        }

        // POST: Search Events by City
        [HttpPost]
        public ActionResult SearchByCity(string city)
        {
            if (Session["UserID"] == null)
            {
                return RedirectToAction("Login", "Account");
            }

            // Search for approved events based on the city and ensure they are active (future dates)
            var filteredEvents = db.Events
                .Where(e => e.City.Contains(city) && e.EventDate >= DateTime.Now && e.Status == "Approved")
                .ToList();

            return View(filteredEvents);  // Display the filtered results in the same view
        }

        // GET: View Event Details
        [HttpGet]
        public ActionResult EventDetails(int id)
        {
            if (Session["UserID"] == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var eventDetails = db.Events.Find(id);
            if (eventDetails == null)
            {
                return HttpNotFound();
            }

            return View(eventDetails);
        }

        // Utility method to calculate distance using Google Distance Matrix API
        private async Task<double> CalculateDistanceAsync(string city1, string city2)
        {
            string url = $"https://maps.googleapis.com/maps/api/distancematrix/json?units=metric&origins={city1}&destinations={city2}&key={googleApiKey}";

            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage response = await client.GetAsync(url);
                if (response.IsSuccessStatusCode)
                {
                    string jsonResult = await response.Content.ReadAsStringAsync();
                    JObject json = JObject.Parse(jsonResult);

                    var rows = json["rows"].FirstOrDefault();
                    if (rows != null)
                    {
                        var elements = rows["elements"].FirstOrDefault();
                        if (elements != null && elements["status"].ToString() == "OK")
                        {
                            var distanceInMeters = elements["distance"]["value"].ToObject<double>();
                            var distanceInKilometers = distanceInMeters / 1000.0;
                            return distanceInKilometers;
                        }
                    }
                }
            }

            // Default distance in case of error
            return 10000.0; // A very high value to exclude the event if there's an issue
        }


        [HttpGet]
        public ActionResult ViewAllGuests(int eventId)
        {
            var eventDetails = db.Events.Find(eventId);
            if (eventDetails == null)
            {
                return HttpNotFound();
            }

            return View(eventDetails);
        }








        [HttpPost]
        public ActionResult PurchaseTicket(int eventId, string ticketType)
        {
            if (Session["UserID"] == null)
            {
                return RedirectToAction("Login", "Account");
            }

            // Fetch event details
            var selectedEvent = db.Events.Find(eventId);
            if (selectedEvent == null)
            {
                return HttpNotFound();
            }

            // Calculate total amount based on ticket type
            double totalCost = 0;
            switch (ticketType)
            {
                case "General":
                    totalCost = (double)selectedEvent.GeneralTicketPrice;
                    break;
                case "VIP":
                    totalCost = (double)selectedEvent.VIPTicketPrice;
                    break;
                case "VVIP":
                    totalCost = (double)selectedEvent.VVIPTicketPrice;
                    break;
                case "Backstage":
                    totalCost = (double)selectedEvent.BackstagePassPrice;
                    break;
            }

            // Save the total cost in the session
            Session["TotalCost"] = totalCost;
            Session["EventID"] = eventId;
            Session["TicketType"] = ticketType;

            // Redirect to PayPal payment
            return RedirectToAction("PaymentWithPaypal");
        }

        // Payment with PayPal integration
        public ActionResult PaymentWithPaypal()
        {
            string clientId = ConfigurationManager.AppSettings["paypal:clientId"];
            string clientSecret = ConfigurationManager.AppSettings["paypal:clientSecret"];
            var config = ConfigManager.Instance.GetProperties();
            var accessToken = new OAuthTokenCredential(clientId, clientSecret, config).GetAccessToken();
            var apiContext = new APIContext(accessToken);

            double totalCost = Convert.ToDouble(Session["TotalCost"])/18;
            string totalAsString = totalCost.ToString("F2", CultureInfo.InvariantCulture);

            var payment = new Payment()
            {
                intent = "sale",
                payer = new Payer { payment_method = "paypal" },
                transactions = new List<PayPal.Api.Transaction>
                {
                    new PayPal.Api.Transaction
                    {
                        description = "Event Ticket Purchase",
                        invoice_number = new Random().Next(100000).ToString(),
                        amount = new Amount
                        {
                            currency = "USD",
                            total = totalAsString,
                        }
                    }
                },
                redirect_urls = new RedirectUrls
                {
                    return_url = Url.Action("PaymentSuccessful", "Customer", null, protocol: Request.Url.Scheme),
                    cancel_url = Url.Action("PaymentFailed", "Customer", null, protocol: Request.Url.Scheme)
                }
            };

            payment = payment.Create(apiContext);
            var approvalUrl = payment.links.FirstOrDefault(link => link.rel == "approval_url").href;

            return Redirect(approvalUrl);
        }

        // Payment successful
        public ActionResult PaymentSuccessful()
        {
            if (Session["UserID"] == null || Session["TotalCost"] == null || Session["EventID"] == null || Session["TicketType"] == null)
            {
                return RedirectToAction("Home");
            }

            int userId = (int)Session["UserID"];
            int eventId = (int)Session["EventID"];
            string ticketType = Session["TicketType"].ToString();
            double totalAmount = (double)Session["TotalCost"];

            // Fetch the event
            var selectedEvent = db.Events.Find(eventId);
            if (selectedEvent == null)
            {
                return HttpNotFound();
            }

            // Decrease the event capacity by 1
            if (selectedEvent.Capacity > 0)
            {
                selectedEvent.Capacity -= 1;
                db.SaveChanges();
            }
            else
            {
                return View("EventSoldOut");
            }

            // Generate QR code and PDF for the ticket
            byte[] qrCodeBytes = GenerateQRCode(userId, eventId, ticketType);
            byte[] pdfBytes = GenerateTicketPDF(userId, eventId, ticketType, qrCodeBytes);

            // Save the transaction in the database
            var transaction = new Models.Transaction
            {
                UserID = userId,
                EventID = eventId,
                TicketType = ticketType,
                Quantity = 1,
                TotalAmount = (decimal)totalAmount,
                PaymentMethod = "PayPal",
                PaymentStatus = "Completed",
                QRCode = qrCodeBytes,
                TicketPDF = pdfBytes,
                DatePurchased = DateTime.Now
            };
            db.Transactions.Add(transaction);

            // Update the TicketSalesSummary table
            var ticketSalesSummary = db.TicketSalesSummaries.SingleOrDefault(t => t.EventID == eventId);
            if (ticketSalesSummary != null)
            {
                // Update existing record
                ticketSalesSummary.TotalTicketsSold += 1;
                ticketSalesSummary.TotalRevenue += (decimal)totalAmount;
            }
            else
            {
                // Create a new record
                var newTicketSalesSummary = new Models.TicketSalesSummary
                {
                    EventID = eventId,
                    TotalTicketsSold = 1,
                    TotalRevenue = (decimal)totalAmount
                };
                db.TicketSalesSummaries.Add(newTicketSalesSummary);
            }

            // Save the Ticket information in the Tickets table
            var ticket = new Models.Ticket
            {
                EventID = eventId,
                TicketType = ticketType,
                Price = (decimal)totalAmount,
                DateCreated = DateTime.Now
            };
            db.Tickets.Add(ticket);

            // Save all changes
            db.SaveChanges();

            // Send confirmation email
            var user = db.Users.Find(userId);
            if (user != null)
            {
                SendTicketEmail(user.Email, pdfBytes);
            }

            return View("PaymentSuccessful");
        }

      	public ActionResult PaymentFailed()
	        {
	            return View("PaymentFailed");
            }

       
        private byte[] GenerateQRCode(int userId, int eventId, string ticketType)
        {
            var user = db.Users.Find(userId);
            var selectedEvent = db.Events.Find(eventId);

            if (user == null || selectedEvent == null)
            {
                return null;
            }

            // Simplify and compact the data
            var qrDataObject = new
            {
                UID = user.UserID,
                Name = user.FullName,
                EID = selectedEvent.EventID,
                Event = selectedEvent.EventName,
                Type = ticketType,
                Date = selectedEvent.EventDate.ToString("yyyy-MM-dd")
            };

            // Serialize the data to JSON
            string qrData = JsonConvert.SerializeObject(qrDataObject);

            var qrGenerator = new QRCodeGenerator();

            // Use a lower error correction level to reduce QR code complexity if necessary
            var qrCodeData = qrGenerator.CreateQrCode(qrData, QRCodeGenerator.ECCLevel.M);

            var qrCode = new BitmapByteQRCode(qrCodeData);

            // Increase pixels per module for higher resolution
            return qrCode.GetGraphic(20);  // Adjust as needed
        }

        // Utility: Generate PDF Ticket with QR Code and Event Details
        private byte[] GenerateTicketPDF(int userId, int eventId, string ticketType, byte[] qrCodeBytes)
        {
            var user = db.Users.Find(userId);
            var selectedEvent = db.Events.Find(eventId);

            if (user == null || selectedEvent == null)
            {
                throw new Exception("User or Event not found");
            }

            using (var memoryStream = new MemoryStream())
            {
                PdfWriter writer = new PdfWriter(memoryStream);
                PdfDocument pdf = new PdfDocument(writer);
                Document document = new Document(pdf);

                // Add title and details to the PDF
                document.Add(new Paragraph("Event Ticket").SetFontSize(24).SetBold().SetTextAlignment(TextAlignment.CENTER));
                document.Add(new Paragraph($"Ticket Type: {ticketType}").SetTextAlignment(TextAlignment.LEFT));
                document.Add(new Paragraph($"User: {user.FullName}").SetTextAlignment(TextAlignment.LEFT));
                document.Add(new Paragraph($"Event: {selectedEvent.EventName}").SetTextAlignment(TextAlignment.LEFT));
                document.Add(new Paragraph($"Event Date: {selectedEvent.EventDate:yyyy-MM-dd}").SetTextAlignment(TextAlignment.LEFT));
                document.Add(new Paragraph($"Location: {selectedEvent.Address}, {selectedEvent.City}").SetTextAlignment(TextAlignment.LEFT));

                // Add QR Code Image with increased size
                ImageData qrImageData = ImageDataFactory.Create(qrCodeBytes);
                iText.Layout.Element.Image qrImage = new iText.Layout.Element.Image(qrImageData);
                qrImage.SetWidth(200).SetHeight(200); // Increased size
                document.Add(qrImage.SetHorizontalAlignment(HorizontalAlignment.CENTER));

                document.Close();
                return memoryStream.ToArray(); // Returns PDF as byte array
            }
        }
        


        // Utility: Send Ticket via Email
        private void SendTicketEmail(string email, byte[] pdfBytes)
        {
            string fromEmail = "sandileisaacmbonambi@gmail.com"; // Your email
            string fromPassword = "tdnxixxqbgzqzlym"; // App password

            MailMessage mailMessage = new MailMessage();
            mailMessage.From = new MailAddress(fromEmail, "EventFinder");
            mailMessage.To.Add(new MailAddress(email));
            mailMessage.Subject = "Your Event Ticket";
            mailMessage.Body = "Please find your event ticket attached.";
            mailMessage.IsBodyHtml = true;

            // Attach PDF Ticket
            mailMessage.Attachments.Add(new Attachment(new MemoryStream(pdfBytes), "EventTicket.pdf"));

            // Configure SMTP Client
            SmtpClient smtpClient = new SmtpClient("smtp.gmail.com", 587)
            {
                Credentials = new System.Net.NetworkCredential(fromEmail, fromPassword),
                EnableSsl = true
            };

            smtpClient.Send(mailMessage);  
        }


        [HttpGet]
        public ActionResult MyTickets()
        {
            if (Session["UserID"] == null)
            {
                return RedirectToAction("Login", "Account");
            }

            int userId = (int)Session["UserID"];

            // Get all transactions related to the logged-in user
            var transactions = db.Transactions
                                .Where(t => t.UserID == userId)
                                .Select(t => new MyTicketViewModel
                                {
                                    TransactionID = t.TransactionID,
                                    TicketType = t.TicketType,
                                    TotalAmount = t.TotalAmount,
                                    DatePurchased = (DateTime)t.DatePurchased,
                                    EventName = t.Event.EventName,
                                    EventPoster = t.Event.Poster,
                                    EventType = t.Event.EventType.EventTypeName
                                }).ToList();

            // Pass data to the view
            return View(transactions);
        }

        [HttpGet]
        public ActionResult TicketDetails(int transactionId)
        {
            if (Session["UserID"] == null)
            {
                return RedirectToAction("Login", "Account");
            }

            var transaction = db.Transactions
                .Where(t => t.TransactionID == transactionId)
                .Select(t => new MyTicketViewModel
                {
                    TransactionID = t.TransactionID,
                    TicketType = t.TicketType,
                    TotalAmount = t.TotalAmount,
                    DatePurchased = (DateTime)t.DatePurchased,
                    EventName = t.Event.EventName,
                    EventType = t.Event.EventType.EventTypeName,
                    EventPoster = t.Event.Poster
                })
                .FirstOrDefault();

            if (transaction == null)
            {
                return HttpNotFound();
            }

            return View(transaction);
        }

        [HttpGet]
        public FileResult DownloadTicket(int transactionId)
        {
            var transaction = db.Transactions.Find(transactionId);
            if (transaction == null || transaction.TicketPDF == null)
            {
                return null;
            }

            return File(transaction.TicketPDF, "application/pdf", "EventTicket.pdf");
        }



    }
}
