﻿using EventFinder.Models;
using EventFinder.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EventFinder.Controllers
{
    public class OrganizerController : Controller
    {
        private EventDBEntities5 db = new EventDBEntities5();

        // GET: Organizer Home
        public ActionResult Home()
        {
            if (Session["OrganizerID"] == null)
            {
                return RedirectToAction("LoginOrganizer", "Account");
            }
            return View();
        }

        // GET: Create Event
        [HttpGet]
        public ActionResult CreateEvent()
        {
            if (Session["OrganizerID"] == null)
            {
                return RedirectToAction("LoginOrganizer", "Account");
            }

            ViewBag.EventTypes = new SelectList(db.EventTypes.ToList(), "EventTypeID", "EventTypeName");
            return View();
        }

        // POST: Create Event
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CreateEvent(CreateEventViewModel model)
        {
            if (Session["OrganizerID"] == null)
            {
                return RedirectToAction("LoginOrganizer", "Account");
            }

            if (ModelState.IsValid)
            {
                // Convert poster file to byte array
                byte[] posterData = null;
                if (model.Poster != null && model.Poster.ContentLength > 0)
                {
                    posterData = new byte[model.Poster.ContentLength];
                    model.Poster.InputStream.Read(posterData, 0, model.Poster.ContentLength);
                }

                // Create event
                var newEvent = new Event
                {
                    OrganizerID = (int)Session["OrganizerID"],
                    EventName = model.EventName,
                    EventTypeID = model.EventTypeID,
                    EventDate = model.EventDate,
                    Address = model.Address,
                    City = model.City,
                    Capacity = model.Capacity,
                    GeneralTicketPrice = model.GeneralTicketPrice,
                    VIPTicketPrice = model.VIPTicketPrice,
                    VVIPTicketPrice = model.VVIPTicketPrice,
                    BackstagePassPrice = model.BackstagePassPrice,
                    Poster = posterData,
                    DateCreated = DateTime.Now,
                    Status = "Pending"
                };

                db.Events.Add(newEvent);
                db.SaveChanges();

                // Store EventID in session and redirect to AddGuest page
                Session["EventID"] = newEvent.EventID;
                return RedirectToAction("AddGuest");
            }

            ViewBag.EventTypes = new SelectList(db.EventTypes.ToList(), "EventTypeID", "EventTypeName");
            return View(model);
        }

        // GET: Add Guest
        [HttpGet]
        public ActionResult AddGuest()
        {
            if (Session["EventID"] == null)
            {
                return RedirectToAction("CreateEvent");
            }

            return View();
        }

        // POST: Add Guest
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddGuest(AddGuestViewModel model)
        {
            if (Session["EventID"] == null)
            {
                return RedirectToAction("CreateEvent");
            }

            if (ModelState.IsValid)
            {
                // Convert profile picture to byte array
                byte[] profilePicData = null;
                if (model.ProfilePic != null && model.ProfilePic.ContentLength > 0)
                {
                    profilePicData = new byte[model.ProfilePic.ContentLength];
                    model.ProfilePic.InputStream.Read(profilePicData, 0, model.ProfilePic.ContentLength);
                }

                // Add guest to the event
                var newGuest = new Guest
                {
                    EventID = (int)Session["EventID"],
                    GuestName = model.GuestName,
                    StageName = model.StageName,
                    Profession = model.Profession,
                    Biography = model.Biography,
                    ProfilePic = profilePicData,
                    DateAdded = DateTime.Now
                };

                db.Guests.Add(newGuest);
                db.SaveChanges();

                // Redirect back to the same page for adding more guests
                return RedirectToAction("AddGuest");
            }

            return View(model);
        }

        // GET: Finish Event
        public ActionResult FinishEvent()
        {
            if (Session["EventID"] == null)
            {
                return RedirectToAction("CreateEvent");
            }

            // Clear EventID from session and redirect to success page
            Session.Remove("EventID");
            return RedirectToAction("EventSuccess");
        }

        // GET: Event Success
        public ActionResult EventSuccess()
        {
            return View();
        }


        public ActionResult MyEvents()
        {
            if (Session["OrganizerID"] == null)
            {
                return RedirectToAction("LoginOrganizer", "Account");
            }

            int organizerId = (int)Session["OrganizerID"];
            var events = db.Events.Where(e => e.OrganizerID == organizerId).ToList();

            return View(events);
        }

        // GET: Event Details
        public ActionResult EventDetails(int id)
        {
            if (Session["OrganizerID"] == null)
            {
                return RedirectToAction("LoginOrganizer", "Account");
            }

            var selectedEvent = db.Events.Find(id);
            if (selectedEvent == null || selectedEvent.OrganizerID != (int)Session["OrganizerID"])
            {
                return HttpNotFound();
            }

            return View(selectedEvent);
        }

        // GET: View Analysis
        public ActionResult ViewAnalysis(int id)
        {
            if (Session["OrganizerID"] == null)
            {
                return RedirectToAction("LoginOrganizer", "Account");
            }

            int organizerId = (int)Session["OrganizerID"];

            // Ensure the event belongs to this organizer
            var selectedEvent = db.Events.FirstOrDefault(e => e.EventID == id && e.OrganizerID == organizerId);

            if (selectedEvent == null)
            {
                return HttpNotFound();
            }

            // Fetch the required data for analysis
            // Total tickets sold
            var totalTicketsSold = db.Transactions
                .Where(t => t.EventID == id && t.PaymentStatus == "Completed")
                .Sum(t => (int?)t.Quantity) ?? 0;

            // Number of tickets sold per ticket type
            var ticketsByType = db.Transactions
                .Where(t => t.EventID == id && t.PaymentStatus == "Completed")
                .GroupBy(t => t.TicketType)
                .Select(g => new
                {
                    TicketType = g.Key,
                    TicketsSold = g.Sum(t => (int?)t.Quantity) ?? 0,
                    Revenue = g.Sum(t => (decimal?)t.TotalAmount) ?? 0
                })
                .ToList();

            // Total revenue
            var totalRevenue = db.Transactions
                .Where(t => t.EventID == id && t.PaymentStatus == "Completed")
                .Sum(t => (decimal?)t.TotalAmount) ?? 0;

            // Prepare data for charts
            var model = new EventAnalysisViewModel
            {
                EventID = id,
                EventName = selectedEvent.EventName,
                TotalTicketsSold = totalTicketsSold,
                TotalRevenue = totalRevenue,
                TicketsByType = ticketsByType.Select(t => new TicketTypeAnalysis
                {
                    TicketType = t.TicketType,
                    TicketsSold = t.TicketsSold,
                    Revenue = t.Revenue
                }).ToList()
            };

            return View(model);
        }
    }
}
