﻿using EventFinder.Models;
using System;
using System.Linq;
using System.Web.Mvc;

namespace EventFinder.Controllers
{
    public class AdminController : Controller
    {
        private EventDBEntities5 db = new EventDBEntities5();

        // GET: Admin Home
        [HttpGet]
        public ActionResult Home()
        {
            if (Session["UserID"] == null)
            {
                return RedirectToAction("Login", "Account");
            }

            return View();
        }

        // GET: Pending Events
        [HttpGet]
        public ActionResult PendingEvents()
        {
            if (Session["UserID"] == null)
            {
                return RedirectToAction("Login", "Account");
            }

            // Fetch all events with "Pending" status
            var pendingEvents = db.Events.Where(e => e.Status == "Pending").ToList();
            return View(pendingEvents);
        }

        // GET: Review Event
        [HttpGet]
        public ActionResult ReviewEvent(int id)
        {
            if (Session["UserID"] == null)
            {
                return RedirectToAction("Login", "Account");
            }

            // Fetch the event with the specified ID
            var eventDetails = db.Events.Find(id);
            if (eventDetails == null)
            {
                return HttpNotFound();
            }

            return View(eventDetails);
        }

        // POST: Approve Event
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ApproveEvent(int id)
        {
            if (Session["UserID"] == null)
            {
                return RedirectToAction("Login", "Account");
            }

            // Find the event and update its status to "Approved"
            var eventToApprove = db.Events.Find(id);
            if (eventToApprove != null)
            {
                eventToApprove.Status = "Approved";
                db.SaveChanges();

                // Optionally, notify the event organizer (e.g., via email)
            }

            return RedirectToAction("PendingEvents");
        }

        // POST: Reject Event
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult RejectEvent(int id)
        {
            if (Session["UserID"] == null)
            {
                return RedirectToAction("Login", "Account");
            }

            // Find the event and update its status to "Rejected"
            var eventToReject = db.Events.Find(id);
            if (eventToReject == null)
            {
                // Return an error view or redirect with an error message if the event is not found
                TempData["ErrorMessage"] = "The event could not be found or has already been processed.";
                return RedirectToAction("PendingEvents");
            }

            try
            {
                eventToReject.Status = "Rejected";
                db.SaveChanges();
            }
            catch (Exception)
            {
                // Log the exception or handle it as appropriate
                TempData["ErrorMessage"] = "An error occurred while rejecting the event. Please try again.";
                // Optionally log the exception details: ex.Message, ex.StackTrace, etc.
            }

            return RedirectToAction("PendingEvents");
        }

    }
}
