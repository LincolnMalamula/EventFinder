﻿using EventFinder.Models;
using EventFinder.Models.ViewModels;
using System;
using System.Linq;
using System.Web.Mvc;

namespace EventFinder.Controllers
{
    public class AccountController : Controller
    {
        private EventDBEntities5 db = new EventDBEntities5();


        public ActionResult Home()
        {
            return View();
        }

        // GET: Customer Registration
        [HttpGet]
        public ActionResult RegisterCustomer()
        {
            return View();
        }

        // POST: Customer Registration
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult RegisterCustomer(CustomerRegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                // Check if email already exists
                if (db.Users.Any(u => u.Email == model.Email))
                {
                    ModelState.AddModelError("", "Email is already registered.");
                    return View(model);
                }

                // Create new customer account
                var user = new User
                {
                    FullName = model.FullName,
                    Email = model.Email,
                    Password = model.Password, // Password should be hashed in production
                    Address = model.Address,
                    City = model.City,
                    ContactNumber = model.ContactNumber,
                    Role = "Customer",
                    DateCreated = DateTime.Now
                };

                db.Users.Add(user);
                db.SaveChanges();

                // Send confirmation email (implement email service here)
                // Redirect to confirmation page
                return RedirectToAction("Confirmation");
            }
            return View(model);
        }

        // GET: Event Organizer Registration
        [HttpGet]
        public ActionResult RegisterOrganizer()
        {
            return View();
        }

        // POST: Event Organizer Registration
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult RegisterOrganizer(OrganizerRegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                // Check if email already exists
                if (db.EventOrganizers.Any(o => o.Email == model.Email))
                {
                    ModelState.AddModelError("", "Email is already registered.");
                    return View(model);
                }

                // Create new organizer account
                var organizer = new EventOrganizer
                {
                    FullName = model.FullName,
                    Email = model.Email,
                    Password = model.Password, // Password should be hashed in production
                    CompanyName = model.CompanyName,
                    Address = model.Address,
                    ContactNumber = model.ContactNumber,
                    DateCreated = DateTime.Now
                };

                db.EventOrganizers.Add(organizer);
                db.SaveChanges();

                // Send confirmation email (implement email service here)
                // Redirect to confirmation page
                return RedirectToAction("Confirmation");
            }
            return View(model);
        }

        // GET: Confirmation Page
        public ActionResult Confirmation()
        {
            return View();
        }

        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }

        // POST: Customer/Admin Login
      [HttpPost]
[ValidateAntiForgeryToken]
public ActionResult Login(LoginViewModel model)
{
    if (ModelState.IsValid)
    {
        var user = db.Users.FirstOrDefault(u => u.Email == model.Email);

        if (user == null)
        {
            
            ModelState.AddModelError("Email", "Email does not exist.");
        }
        else if (user.Password != model.Password)
        {
           
            ModelState.AddModelError("Password", "Password is incorrect.");
        }
        else
        {
            // Successful login
            Session["UserID"] = user.UserID;
            Session["UserName"] = user.FullName;
            Session["UserRole"] = user.Role;

            if (user.Role == "Admin")
            {
                return RedirectToAction("Home", "Admin");
            }
            else if (user.Role == "Customer")
            {
                return RedirectToAction("Home", "Customer");
            }
        }
    }
    return View(model);
}

        // GET: Event Organizer Login
        [HttpGet]
        public ActionResult LoginOrganizer()
        {
            return View();
        }

        // POST: Event Organizer Login
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LoginOrganizer(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                var organizer = db.EventOrganizers.FirstOrDefault(o => o.Email == model.Email && o.Password == model.Password);
                if (organizer != null)
                {
                    // Store organizer session
                    Session["OrganizerID"] = organizer.OrganizerID;
                    Session["OrganizerName"] = organizer.FullName;

                    // Redirect to Organizer Dashboard or Home
                    return RedirectToAction("Home", "Organizer");
                }
                else
                {
                    ModelState.AddModelError("", "Invalid email or password.");
                }
            }
            return View(model);
        }

     

        // Log out action (for both customers/admins and organizers)
        public ActionResult Logout()
        {
            Session.Clear(); // Clear all session data
            return RedirectToAction("Login");
        }
    }
}
